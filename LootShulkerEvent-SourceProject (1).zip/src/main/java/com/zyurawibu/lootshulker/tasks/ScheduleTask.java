package com.zyurawibu.lootshulker.tasks;

import com.zyurawibu.lootshulker.LootShulkerEvent;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.scheduler.BukkitRunnable;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ScheduleTask extends BukkitRunnable {

    private final LootShulkerEvent plugin;
    private final Set<String> spawnTimes;
    private String lastTriggeredTime = "";

    public ScheduleTask(LootShulkerEvent plugin) {
        this.plugin = plugin;
        this.spawnTimes = new HashSet<>();
        loadSchedule();
    }

    private void loadSchedule() {
        this.spawnTimes.clear();
        FileConfiguration config = plugin.getConfig();
        List<String> times = config.getStringList("schedule");
        for (String time : times) {
            // Trim and validate simple HH:mm
            if (time != null && time.matches("\\d{2}:\\d{2}")) {
                this.spawnTimes.add(time.trim());
            }
        }
        plugin.getLogger().info("Terbaca " + spawnTimes.size() + " jadwal spawn dari config.");
    }

    @Override
    public void run() {
        // Load schedule dynamically if needed or just use active
        LocalTime now = LocalTime.now();
        String formattedTime = now.format(DateTimeFormatter.ofPattern("HH:mm"));

        if (spawnTimes.contains(formattedTime)) {
            // Prevent duplicate executions in the same minute
            if (!lastTriggeredTime.equals(formattedTime)) {
                lastTriggeredTime = formattedTime;
                
                // Run on main thread because block setting is synchronized
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    plugin.getLogger().info("Mencapai jam " + formattedTime + "! Memulai event shulker box...");
                    plugin.getLootManager().spawnShulkerEvent();
                });
            }
        } else {
            // Clear last triggered if time has moved on
            if (!lastTriggeredTime.equals(formattedTime)) {
                lastTriggeredTime = "";
            }
        }
    }
}