package com.zyurawibu.lootshulker.managers;

import com.zyurawibu.lootshulker.LootShulkerEvent;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.ShulkerBox;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.logging.Level;

public class LootManager {

    private final LootShulkerEvent plugin;
    
    // Config values
    private String worldName;
    private boolean useWorldBorder;
    private int minX, maxX, minZ, maxZ;
    private int despawnMinutes;
    private int lootMinItems, lootMaxItems;
    private List<LootItem> lootPool;

    // Messages
    private String spawnMsg;
    private String despawnMsg;
    private String foundMsg;

    // Active state
    private Location activeShulkerLocation = null;
    private BukkitTask despawnTask = null;

    public LootManager(LootShulkerEvent plugin) {
        this.plugin = plugin;
        loadConfig();
    }

    public void loadConfig() {
        FileConfiguration config = plugin.getConfig();
        this.worldName = config.getString("world", "world");
        this.useWorldBorder = config.getBoolean("use-world-border", true);
        this.minX = config.getInt("min-x", -1500);
        this.maxX = config.getInt("max-x", 1500);
        this.minZ = config.getInt("min-z", -1500);
        this.maxZ = config.getInt("max-z", 1500);
        this.despawnMinutes = config.getInt("despawn-minutes", 30);
        
        this.spawnMsg = config.getString("messages.spawn", "&6&l[LootShulker] &eShulker Box Event muncul di &c%x%, %y%, %z%!");
        this.despawnMsg = config.getString("messages.despawn", "&6&l[LootShulker] &cWaktu habis! Shulker Event menghilang!");
        this.foundMsg = config.getString("messages.found", "&6&l[LootShulker] &aPemain &e%player% &atelah mengamankan Shulker Box!");

        this.lootMinItems = config.getInt("loot-table.min-items", 4);
        this.lootMaxItems = config.getInt("loot-table.max-items", 8);

        this.lootPool = new ArrayList<>();
        ConfigurationSection itemsSec = config.getConfigurationSection("loot-table.items");
        if (itemsSec != null) {
            for (String key : itemsSec.getKeys(false)) {
                ConfigurationSection itemData = itemsSec.getConfigurationSection(key);
                if (itemData != null) {
                    try {
                        String matName = itemData.getString("material");
                        Material material = Material.valueOf(matName != null ? matName.toUpperCase() : "STONE");
                        String displayName = itemData.getString("display-name");
                        int chance = itemData.getInt("chance", 50);
                        int minAmount = itemData.getInt("min-amount", 1);
                        int maxAmount = itemData.getInt("max-amount", 1);

                        List<LootEnchant> enchants = new ArrayList<>();
                        ConfigurationSection enchSec = itemData.getConfigurationSection("enchants");
                        if (enchSec != null) {
                            for (String enchKey : enchSec.getKeys(false)) {
                                ConfigurationSection enchData = enchSec.getConfigurationSection(enchKey);
                                if (enchData != null) {
                                    String encName = enchData.getString("name");
                                    int level = enchData.getInt("level", 1);
                                    Enchantment enchantment = Enchantment.getByName(encName != null ? encName.toUpperCase() : "");
                                    if (enchantment != null) {
                                        enchants.add(new LootEnchant(enchantment, level));
                                    }
                                }
                            }
                        }

                        this.lootPool.add(new LootItem(material, displayName, chance, minAmount, maxAmount, enchants));
                    } catch (Exception e) {
                        plugin.getLogger().warning("Gagal me-load item pvp di config pada key: " + key);
                    }
                }
            }
        } else {
            // Fallback load manually if config lists as a list format instead
            List<?> itemsList = config.getList("loot-table.items");
            if (itemsList != null) {
                for (Object obj : itemsList) {
                    if (obj instanceof Map) {
                        try {
                            Map<?, ?> map = (Map<?, ?>) obj;
                            String matName = (String) map.get("material");
                            Material material = Material.valueOf(matName != null ? matName.toUpperCase() : "STONE");
                            String displayName = (String) map.get("display-name");
                            int chance = map.get("chance") != null ? ((Number) map.get("chance")).intValue() : 50;
                            int minAmount = map.get("min-amount") != null ? ((Number) map.get("min-amount")).intValue() : 1;
                            int maxAmount = map.get("max-amount") != null ? ((Number) map.get("max-amount")).intValue() : 1;

                            List<LootEnchant> enchants = new ArrayList<>();
                            List<?> enchList = (List<?>) map.get("enchants");
                            if (enchList != null) {
                                for (Object enchObj : enchList) {
                                    if (enchObj instanceof Map) {
                                        Map<?, ?> enchMap = (Map<?, ?>) enchObj;
                                        String encName = (String) enchMap.get("name");
                                        int level = enchMap.get("level") != null ? ((Number) enchMap.get("level")).intValue() : 1;
                                        Enchantment enchantment = Enchantment.getByName(encName != null ? encName.toUpperCase() : "");
                                        if (enchantment != null) {
                                            enchants.add(new LootEnchant(enchantment, level));
                                        }
                                    }
                                }
                            }
                            this.lootPool.add(new LootItem(material, displayName, chance, minAmount, maxAmount, enchants));
                        } catch (Exception e) {
                            plugin.getLogger().log(Level.WARNING, "Gagal memproses loot-table list item: ", e);
                        }
                    }
                }
            }
        }
    }

    public boolean spawnShulkerEvent() {
        // Despawn previous if exists
        forceDespawnActiveShulker(false);

        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            plugin.getLogger().severe("World '" + worldName + "' tidak ditemukan! Event Shulker dibatalkan.");
            return false;
        }

        int spawnMinX = minX;
        int spawnMaxX = maxX;
        int spawnMinZ = minZ;
        int spawnMaxZ = maxZ;

        if (useWorldBorder) {
            org.bukkit.WorldBorder border = world.getWorldBorder();
            Location center = border.getCenter();
            double size = border.getSize();
            double halfSize = (size / 2.0) - 100.0; // 100 blocks safe padding inside border
            if (halfSize < 10) halfSize = size / 2.0;

            spawnMinX = (int) (center.getX() - halfSize);
            spawnMaxX = (int) (center.getX() + halfSize);
            spawnMinZ = (int) (center.getZ() - halfSize);
            spawnMaxZ = (int) (center.getZ() + halfSize);
        }

        // Generate random coordinates
        Random random = new Random();
        int x = random.nextInt((spawnMaxX - spawnMinX) + 1) + spawnMinX;
        int z = random.nextInt((spawnMaxZ - spawnMinZ) + 1) + spawnMinZ;
        
        // Find highest block
        int y = world.getHighestBlockYAt(x, z);
        
        // Let's adjust coordinate to be on top of solid block
        Location loc = new Location(world, x, y + 1, z);
        Block block = loc.getBlock();
        
        // Prevent floating/underwater/lava spawning if possible (simple validation)
        Block blockBelow = world.getBlockAt(x, y, z);
        if (blockBelow.getType() == Material.LAVA || blockBelow.getType() == Material.WATER) {
            // Search coordinates again, recursively (limit max 5 attempts)
            for (int i = 0; i < 5; i++) {
                x = random.nextInt((spawnMaxX - spawnMinX) + 1) + spawnMinX;
                z = random.nextInt((spawnMaxZ - spawnMinZ) + 1) + spawnMinZ;
                y = world.getHighestBlockYAt(x, z);
                loc = new Location(world, x, y + 1, z);
                blockBelow = world.getBlockAt(x, y, z);
                if (blockBelow.getType() != Material.LAVA && blockBelow.getType() != Material.WATER) {
                    break;
                }
            }
        }

        // Set to Purple or Magenta Shulker Box
        block.setType(Material.PURPLE_SHULKER_BOX);
        
        if (block.getState() instanceof ShulkerBox) {
            ShulkerBox shulker = (ShulkerBox) block.getState();
            shulker.setCustomName(ChatColor.translateAlternateColorCodes('&', "&d&lLoot Shulker Box"));
            shulker.update();

            // Populate Inventory
            fillShulkerWithLoot(shulker);

            this.activeShulkerLocation = loc;

            // Broadcast message
            broadcastMessage(spawnMsg, loc, null);

            // Start 30-minute auto-despawn task
            startDespawnTimer(loc);

            // Play particles & Sound
            world.playSound(loc, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
            world.spawnParticle(Particle.PORTAL, loc.clone().add(0.5, 0.5, 0.5), 100, 0.5, 0.5, 0.5, 0.1);

            plugin.getLogger().info("Loot Shulker telah spawn di: " + x + ", " + (y+1) + ", " + z);
            return true;
        } else {
            plugin.getLogger().severe("Gagal men-cast block ke ShulkerBox di " + loc.toString());
            return false;
        }
    }

    private void fillShulkerWithLoot(ShulkerBox shulker) {
        Inventory inv = shulker.getInventory();
        inv.clear();

        if (lootPool.isEmpty()) {
            plugin.getLogger().warning("Loot pool kosong! Shulker tidak terisi item PvP.");
            return;
        }

        Random random = new Random();
        int itemsToSpawn = random.nextInt((lootMaxItems - lootMinItems) + 1) + lootMinItems;
        
        // Shuffle candidates that hit their chances
        List<ItemStack> rolledItems = new ArrayList<>();
        Collections.shuffle(lootPool);

        for (LootItem lootItem : lootPool) {
            if (rolledItems.size() >= itemsToSpawn) break;

            if (random.nextInt(100) < lootItem.chance) {
                int amount = random.nextInt((lootItem.maxAmount - lootItem.minAmount) + 1) + lootItem.minAmount;
                ItemStack item = new ItemStack(lootItem.material, amount);
                ItemMeta meta = item.getItemMeta();
                
                if (meta != null) {
                    if (lootItem.displayName != null && !lootItem.displayName.isEmpty()) {
                        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', lootItem.displayName));
                    }
                    
                    // Add Enchants
                    for (LootEnchant enc : lootItem.enchants) {
                        meta.addEnchant(enc.enchantment, enc.level, true);
                    }
                    item.setItemMeta(meta);
                }
                rolledItems.add(item);
            }
        }

        // Place items in random slots inside Shulker Box (27 slots)
        for (ItemStack item : rolledItems) {
            int slot = random.nextInt(27);
            while (inv.getItem(slot) != null) {
                slot = random.nextInt(27);
            }
            inv.setItem(slot, item);
        }
        
        shulker.update(true, true);
    }

    private void startDespawnTimer(Location loc) {
        this.despawnTask = new BukkitRunnable() {
            @Override
            public void run() {
                forceDespawnActiveShulker(true);
            }
        }.runTaskLater(plugin, 20L * 60L * despawnMinutes);
    }

    public void forceDespawnActiveShulker(boolean showBroadcast) {
        if (this.despawnTask != null) {
            this.despawnTask.cancel();
            this.despawnTask = null;
        }

        if (activeShulkerLocation != null) {
            Block block = activeShulkerLocation.getBlock();
            if (block.getType() == Material.PURPLE_SHULKER_BOX || block.getType().name().contains("SHULKER_BOX")) {
                block.setType(Material.AIR);
                
                if (showBroadcast) {
                    broadcastMessage(despawnMsg, activeShulkerLocation, null);
                }

                // Play effect
                World world = activeShulkerLocation.getWorld();
                if (world != null) {
                    world.spawnParticle(Particle.SMOKE, activeShulkerLocation.clone().add(0.5, 0.5, 0.5), 50, 0.2, 0.2, 0.2, 0.05);
                    world.playSound(activeShulkerLocation, Sound.BLOCK_FIRE_EXTINGUISH, 1.0f, 1.0f);
                }
            }
            activeShulkerLocation = null;
        }
    }

    public void handleShulkerFound(Player player, Location loc) {
        if (this.despawnTask != null) {
            this.despawnTask.cancel();
            this.despawnTask = null;
        }

        broadcastMessage(foundMsg, loc, player);
        activeShulkerLocation = null;

        World world = loc.getWorld();
        if (world != null) {
            world.spawnParticle(Particle.HAPPY_VILLAGER, loc.clone().add(0.5, 0.5, 0.5), 30, 0.3, 0.3, 0.3, 0.1);
            world.playSound(loc, Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.2f);
        }
    }

    public void broadcastMessage(String msgTemplate, Location loc, Player player) {
        if (msgTemplate == null || msgTemplate.isEmpty()) return;

        String msg = msgTemplate
                .replace("%x%", String.valueOf(loc.getBlockX()))
                .replace("%y%", String.valueOf(loc.getBlockY()))
                .replace("%z%", String.valueOf(loc.getBlockZ()))
                .replace("%world%", loc.getWorld() != null ? loc.getWorld().getName() : worldName);

        if (player != null) {
            msg = msg.replace("%player%", player.getName());
        }

        String coloredMsg = ChatColor.translateAlternateColorCodes('&', msg);
        Bukkit.broadcastMessage(coloredMsg);
    }

    public Location getActiveShulkerLocation() {
        return activeShulkerLocation;
    }

    // Static helper classes
    private static class LootItem {
        final Material material;
        final String displayName;
        final int chance;
        final int minAmount;
        final int maxAmount;
        final List<LootEnchant> enchants;

        LootItem(Material material, String displayName, int chance, int minAmount, int maxAmount, List<LootEnchant> enchants) {
            this.material = material;
            this.displayName = displayName;
            this.chance = chance;
            this.minAmount = minAmount;
            this.maxAmount = maxAmount;
            this.enchants = enchants;
        }
    }

    private static class LootEnchant {
        final Enchantment enchantment;
        final int level;

        LootEnchant(Enchantment enchantment, int level) {
            this.enchantment = enchantment;
            this.level = level;
        }
    }
}