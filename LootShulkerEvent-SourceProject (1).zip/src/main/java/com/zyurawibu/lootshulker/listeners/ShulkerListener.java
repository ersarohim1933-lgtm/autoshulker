package com.zyurawibu.lootshulker.listeners;

import com.zyurawibu.lootshulker.LootShulkerEvent;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;

public class ShulkerListener implements Listener {

    private final LootShulkerEvent plugin;

    public ShulkerListener(LootShulkerEvent plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onShulkerBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        
        // Check if block broken matches our active shulker box
        Location activeLoc = plugin.getLootManager().getActiveShulkerLocation();
        if (activeLoc == null) return;

        if (block.getType() == Material.PURPLE_SHULKER_BOX || block.getType().name().contains("SHULKER_BOX")) {
            Location blockLoc = block.getLocation();
            
            if (blockLoc.getWorld().getName().equals(activeLoc.getWorld().getName()) &&
                blockLoc.getBlockX() == activeLoc.getBlockX() &&
                blockLoc.getBlockY() == activeLoc.getBlockY() &&
                blockLoc.getBlockZ() == activeLoc.getBlockZ()) {
                
                // Active shulker was broken/secured
                Player player = event.getPlayer();
                plugin.getLootManager().handleShulkerFound(player, blockLoc);
            }
        }
    }
}