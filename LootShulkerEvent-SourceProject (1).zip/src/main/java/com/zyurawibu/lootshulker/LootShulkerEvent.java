package com.zyurawibu.lootshulker;

import com.zyurawibu.lootshulker.commands.ShulkerCommand;
import com.zyurawibu.lootshulker.listeners.ShulkerListener;
import com.zyurawibu.lootshulker.managers.LootManager;
import com.zyurawibu.lootshulker.tasks.ScheduleTask;
import org.bukkit.plugin.java.JavaPlugin;

public final class LootShulkerEvent extends JavaPlugin {

    private LootManager lootManager;
    private ScheduleTask scheduleTask;

    @Override
    public void onEnable() {
        // Save default config.yml
        saveDefaultConfig();

        // Initialize Managers
        this.lootManager = new LootManager(this);

        // Register Commands
        if (getCommand("lootshulker") != null) {
            getCommand("lootshulker").setExecutor(new ShulkerCommand(this));
            getCommand("lootshulker").setTabCompleter(new ShulkerCommand(this));
        }

        // Register Listeners
        getServer().getPluginManager().registerEvents(new ShulkerListener(this), this);

        // Start Scheduler checking hours
        this.scheduleTask = new ScheduleTask(this);
        this.scheduleTask.runTaskTimer(this, 20L * 10L, 20L * 30L); // Check every 30 seconds, delay 10s

        getLogger().info("LootShulkerEvent successfully enabled! Created by zyurawibu.");
    }

    @Override
    public void onDisable() {
        // Force despawn active shulker if any to avoid permanent blocks
        if (this.lootManager != null) {
            this.lootManager.forceDespawnActiveShulker(false);
        }
        getLogger().info("LootShulkerEvent has been safely disabled.");
    }

    public LootManager getLootManager() {
        return lootManager;
    }

    public void reloadPlugin() {
        reloadConfig();
        this.lootManager.loadConfig();
        getLogger().info("Configuration successfully reloaded.");
    }
}