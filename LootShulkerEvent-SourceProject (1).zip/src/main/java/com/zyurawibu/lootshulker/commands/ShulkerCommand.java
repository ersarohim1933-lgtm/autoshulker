package com.zyurawibu.lootshulker.commands;

import com.zyurawibu.lootshulker.LootShulkerEvent;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ShulkerCommand implements CommandExecutor, TabCompleter {

    private final LootShulkerEvent plugin;

    public ShulkerCommand(LootShulkerEvent plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase();

        if (sub.equals("spawn")) {
            if (!sender.hasPermission("lootshulkerevent.admin")) {
                sender.sendMessage(ChatColor.RED + "Anda tidak memiliki izin untuk menggunakan perintah ini.");
                return true;
            }

            sender.sendMessage(ChatColor.YELLOW + "Mencoba memunculkan shulker box event...");
            boolean success = plugin.getLootManager().spawnShulkerEvent();
            if (success) {
                Location loc = plugin.getLootManager().getActiveShulkerLocation();
                sender.sendMessage(ChatColor.GREEN + "Shulker event berhasil spawn di " +
                        loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ());
            } else {
                sender.sendMessage(ChatColor.RED + "Gagal memunculkan shulker event. Periksa log server.");
            }
            return true;
        }

        if (sub.equals("despawn")) {
            if (!sender.hasPermission("lootshulkerevent.admin")) {
                sender.sendMessage(ChatColor.RED + "Anda tidak memiliki izin untuk menggunakan perintah ini.");
                return true;
            }

            Location activeLoc = plugin.getLootManager().getActiveShulkerLocation();
            if (activeLoc == null) {
                sender.sendMessage(ChatColor.RED + "Tidak ada shulker event yang sedang aktif!");
                return true;
            }

            plugin.getLootManager().forceDespawnActiveShulker(true);
            sender.sendMessage(ChatColor.GREEN + "Shulker event berhasil dihapus.");
            return true;
        }

        if (sub.equals("reload")) {
            if (!sender.hasPermission("lootshulkerevent.admin")) {
                sender.sendMessage(ChatColor.RED + "Anda tidak memiliki izin untuk menggunakan perintah ini.");
                return true;
            }

            plugin.reloadPlugin();
            sender.sendMessage(ChatColor.GREEN + "Konfigurasi " + plugin.getName() + " berhasil di-reload!");
            return true;
        }

        if (sub.equals("status")) {
            Location activeLoc = plugin.getLootManager().getActiveShulkerLocation();
            if (activeLoc == null) {
                sender.sendMessage(ChatColor.GRAY + "Status Event: " + ChatColor.RED + "TIDAK AKTIF");
            } else {
                sender.sendMessage(ChatColor.GRAY + "Status Event: " + ChatColor.GREEN + "AKTIF");
                sender.sendMessage(ChatColor.GRAY + "Koordinat: " + ChatColor.LIGHT_PURPLE + 
                        "X:" + activeLoc.getBlockX() + " Y:" + activeLoc.getBlockY() + " Z:" + activeLoc.getBlockZ() + 
                        " (" + activeLoc.getWorld().getName() + ")");
            }
            return true;
        }

        sendHelp(sender);
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&d&l--- " + plugin.getName() + " Help ---"));
        sender.sendMessage(ChatColor.GRAY + "/lootshulker status" + ChatColor.WHITE + " - Melihat status event aktif.");
        if (sender.hasPermission("lootshulkerevent.admin")) {
            sender.sendMessage(ChatColor.GRAY + "/lootshulker spawn" + ChatColor.WHITE + " - Memaksa spawn shulker box saat ini.");
            sender.sendMessage(ChatColor.GRAY + "/lootshulker despawn" + ChatColor.WHITE + " - Menghapus shulker box event aktif.");
            sender.sendMessage(ChatColor.GRAY + "/lootshulker reload" + ChatColor.WHITE + " - Me-reload file config.yml.");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> completions = new ArrayList<>(Arrays.asList("status"));
            if (sender.hasPermission("lootshulkerevent.admin")) {
                completions.addAll(Arrays.asList("spawn", "despawn", "reload"));
            }
            return completions.stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }
        return new ArrayList<>();
    }
}